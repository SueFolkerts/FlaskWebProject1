# printing

Printing utils for Windows.


## Install

```shell
pip install win32printing
```

## Installed Utils

- win32printing.get_system_fonts
- win32printing.PrinterBase
- win32printing.PrinterContext
- win32printing.Printer

## Printer APIs

- text(text, align="left", font_config=None)
- new_page()

## Usage Example

```python
from win32printing import Printer

font = {
    "height": 8,
}
with Printer(linegap=1) as printer:
    printer.text("title1", font_config=font)
    printer.text("title2", font_config=font)
    printer.text("title3", font_config=font)
    printer.text("title4", font_config=font)
    printer.new_page()
    printer.text("title5", font_config=font)
    printer.text("title6", font_config=font)
    printer.text("title7", font_config=font)
    printer.text("title8", font_config=font)
```

### Printer init parameters

- printer_name: The printer name which will be used to print. None value means use system default's printer. Default to None.
- doc_name: The file name will be used. None value means "NoNameFile". Default to None.
- margin: The page margin. Default to (0, 0, 0, 0).
- linegap: Gap between two lines.
- default_font: Default font config used in print, will be override by .`text`(..., `font_config`).
- auto_page: Do auto page or not. Default to False means you shuold care about pagination by yourself.

### font_config items

- height
- width
- escapement
- orientation
- weight
- italic
- underline
- strikeOut
- charSet
- outPrecision
- clipPrecision
- quality
- pitchAndFamily
- faceName

Note: See item detail at https://docs.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-createfontw


## Releases

### v0.1.3 2020-06-21

- Add auto_page for Printer.
- Fix Printer(..., `default_font`) not used problem.
- Update doc, add new_page usage in example.

### v0.1.2 2020-02-12

- Fix printer_name parameter not using problem. Thanks to Mark Butsch.

### v0.1.1 2019-10-22

- Fix py_modules problem in setup.py.

### v0.1.0 2019-10-22

- Allow text printing on Windows system.
- Support text alignment and font settings.
- Support linegap setting.

